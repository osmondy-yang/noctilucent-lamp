module.exports = ctx => {
  ctx.state.data = {
    msg: 'Hello World'
  }
}